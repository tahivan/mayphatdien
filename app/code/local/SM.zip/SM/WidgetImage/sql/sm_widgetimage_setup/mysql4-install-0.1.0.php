<?php
/**
 * Created by PhpStorm.
 * User: VanThai
 * Date: 1/27/2015
 * Time: 1:07 AM
 */ 
/* @var $installer Mage_Core_Model_Resource_Setup */
$installer = $this;

$installer->startSetup();



$installer->endSetup();