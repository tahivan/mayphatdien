<?php
/**
 * Created by PhpStorm.
 * User: VanThai
 * Date: 1/27/2015
 * Time: 1:07 AM
 */ 
class SM_WidgetImage_Helper_Data extends Mage_Core_Helper_Abstract {

}